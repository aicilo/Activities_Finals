﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Finals.Models
{
    public class Factorial
    {
        public int Calculate(int number)
        {
            if (number == 0)
            {
                return 1;
            }
            return number * Calculate(number - 1);
        }

        //int result = Factorial(5);
        //Console.WriteLine(result);
    }
}

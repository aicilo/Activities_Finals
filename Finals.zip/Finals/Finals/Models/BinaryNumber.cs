﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Finals.Models
{
    public class BinaryNumber
    {
        public string ConvertToBinary(int decimalNumber) 
        {
            byte[] byteArray = BitConverter.GetBytes(decimalNumber);
            var binaryNumber = string.Join("", byteArray.Select(byt => Convert.ToString(byt, 2).PadLeft(8, '0')));
            return binaryNumber;
        }
    }
}

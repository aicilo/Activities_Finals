﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Finals.Models
{
    public class MinimumValueOfADigitInAn8BitNumber
    {
        public int GetMinimumNumber(int number) //12345678
        {
            char[] digits = number.ToString().ToCharArray();
            int min = digits.Min(x => int.Parse(x.ToString()));
            return min;
        }
    }
}

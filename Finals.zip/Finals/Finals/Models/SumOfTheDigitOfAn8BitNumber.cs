﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Finals.Models
{
    public class SumOfTheDigitOfAn8BitNumber
    {
        public int FindTheSum(int number) //12345678
        {
            char[] digits = number.ToString().ToCharArray();
            int sum = digits.Sum(x => int.Parse(x.ToString()));
            return sum;
        }
    }
}

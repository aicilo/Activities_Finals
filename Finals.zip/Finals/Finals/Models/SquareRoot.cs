﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Finals.Models
{
    public class SquareRoot
    {
        public double Find(double number) 
        {
            double sqrt = Math.Sqrt(number);
            return sqrt;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Finals.Models;

namespace Finals
{
    public partial class frmActivities : Form
    {
        public frmActivities()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var squareRoot = new SquareRoot();
            MessageBox.Show(squareRoot.Find(16).ToString(), "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var factorial = new Factorial();
            MessageBox.Show(factorial.Calculate(5).ToString(), "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var binary = new BinaryNumber();
            MessageBox.Show(binary.ConvertToBinary(10).ToString(), "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var minimumValue = new MinimumValueOfADigitInAn8BitNumber();
            MessageBox.Show(minimumValue.GetMinimumNumber(12345678).ToString(), "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            var sum = new SumOfTheDigitOfAn8BitNumber();
            MessageBox.Show(sum.FindTheSum(12345678).ToString(), "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
